package G36_CENG112_HW4;

public interface IMedia {

		 public String mediaName();
		 public String mediaType();
		 public int mediaPrice();
		 public int mediaYear();
		 public String mediaOwner();
	

}
