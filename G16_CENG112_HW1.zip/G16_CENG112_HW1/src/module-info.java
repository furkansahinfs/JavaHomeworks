/**
 * 
 */
/**
 * @author Furkan
 *
 */
module Odev {
}