package Collections;
import java.util.Stack;

import Exceptions.*;
import Facilities.*;
import Item.*;

public class OpenTopContainer implements IContainer 
{
	
	private double litre; // the litre of items in the container
	private double capacity;// the capacity of container
	private double yeastOTCitre; // if the given item is yeast, this variable holds the litre of yeast.
	private double cacaoOTCitre; // if the given item is cacao, this variable holds the litre of cacao.
	private Stack<IUncountable> openTopContainer;
	private int pozisyon =2 ; // Pozisyon 1: warehouse, 2: factory, 3: distribution center. It holds the position of container
	
	
	public OpenTopContainer() 
	{	openTopContainer = new Stack<IUncountable>();
		yeastOTCitre = 0;
		cacaoOTCitre=0;
		this.capacity=1000;
		this.litre=0;
	}

	
	/**
	 * If the given item is not uncountable, throws ItemNotUncountableException
	 * If it is uncountable control that there exists enough space in the container
	 * then if container is not empty and given item is same with item in the container, invoke the addControl method to add.
	 * if container is empty, invoke the addControl method to add.
	 */
	public<T> boolean add(T obje) throws ItemNotUncountableException, DifferentUncountableItemsException
	{
		if (!(obje instanceof IUncountable))
		{
			throw new  ItemNotUncountableException("item is not uncountable item: "+obje.getClass().getSimpleName());
		}

		boolean result = false;
		if(litre+((IUncountable) obje).getLitre()>capacity) 
		{
			System.out.println("No enough space in Open Top Container");
			return false;
		}
		
		if(!openTopContainer.isEmpty()) 
		{
			if(openTopContainer.get(0).getClass().getSimpleName().equals(obje.getClass().getSimpleName())) 
			{
				result = addControl(obje);
			}
			else 
			{
				throw new DifferentUncountableItemsException("Different uncountable type");
			}
		}
		
		if(openTopContainer.isEmpty()) 
		{
			result = addControl(obje);
		}
		return result;
		
	}
	
	
	/**
	 * Firstly we analyse the type of the item (yeast or cacao)
	 * According to type we add the item to the container and set the litre of container. 
	 */
	public <T> boolean addControl(T obje)
	{
		boolean result = false;
		switch (((IUncountable) obje).getClass().getSimpleName()) 
		{
			case "Yeast":
				Yeast yeast = (Yeast) obje;
				openTopContainer.push(yeast);
				litre= litre + yeast.getLitre();
				yeastOTCitre=yeastOTCitre+yeast.getLitre();
				result = true;
				break;
				
			case "Cacao":
				Cacao cacao = (Cacao) obje;
				openTopContainer.push(cacao);
				litre= litre + cacao.getLitre();
				cacaoOTCitre=cacaoOTCitre+cacao.getLitre();		
				result = true;
				break;
		}
		return result;
		
	}
	
	
	/**
	 * Firstly we analyse the type of the item (yeast or cacao)
	 * According to type we remove the item to the container and set the litre of container. 
	 * If given item is unexpected type, we throw an IllegalArgumentException
	 */
	public<T> boolean remove(T obje) 
	{
		boolean result = false;
		switch (obje.getClass().getSimpleName()) 
		{	
			case "Yeast":
				litre=litre-yeastOTCitre;
				yeastOTCitre=0;
				openTopContainer.clear();
				result = true;		
				break;
				
			case "Cacao":
				litre=litre-cacaoOTCitre;
				cacaoOTCitre =0;
				openTopContainer
				.clear();
				result = true;
				break;
				
			default :
				throw new IllegalArgumentException("Unexpected item is tried to be given to the open top container: " + obje.getClass().getSimpleName() );
		
		}
		
		return result;
	}
		
		
	
	/**
	 * Firstly we analyze the type of the item (yeast or cacao)
	 * and create a new item which its litre is equal to litre of item in the container.
	 * After that we try to transfer (add to facitily) the item. If transfer is succesfull we invoke the remove method of container.
	 *  If given item is unexpected type, we throw an IllegalArgumentException
	 */
	@SuppressWarnings("unchecked")
	public <T> boolean transferTo(T obje,Facilities faci) 
	{
		boolean result = false;
		switch (obje.getClass().getSimpleName()) 
		{
			case "Yeast":
				Yeast yeast = (Yeast) obje;
				yeast.setLitre(yeastOTCitre);
				if(faci.add((T) yeast))
				{
					remove(obje);
					result = true;
				}
				break;
				
			case "Cacao":
				Cacao cacao = (Cacao) obje;
				if(faci.add((T) cacao))
				{
					remove(obje);
					 result = true;
				}
				break;
			default :
				throw new IllegalArgumentException("Unexpected item is tried to be given to the open top container: " + obje.getClass().getSimpleName() );
			
			}
		return result;
	}
	public Stack<IUncountable> getTankContainer() {
		return openTopContainer;
	}

	public void setTankContainer(Stack<IUncountable> openTopContainer) {
		this.openTopContainer = openTopContainer;
	}
	
	public double getYeastOTCitre() {
		return yeastOTCitre;
	}
	public void setYeastOTCitre(double yeastOTCitre) {
		this.yeastOTCitre = yeastOTCitre;
	}
	public double getCacaoOTCitre() {
		return cacaoOTCitre;
	}
	public void setCacaoOTCitre(double cacaoOTCitre) {
		this.cacaoOTCitre = cacaoOTCitre;
	}
	
	public double getLitre() {
		return litre;
	}

	public void setLitre(double litre) {
		this.litre = litre;
	}

	public double getCapacity() {
		return capacity;
	}

	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}

	public int getPozisyon() {
		return pozisyon;
	}

	public void setPozisyon(int pozisyon) {
		this.pozisyon = pozisyon;
	}

}
