package Item;

public interface ICountable {
	
	public double getLitre(); // returns the litre of Icountable item

	public void setLitre(double litre); // sets the litre of Icountable item
	 
	
}
