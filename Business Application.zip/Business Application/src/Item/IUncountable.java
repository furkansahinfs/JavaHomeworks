package Item;

public interface IUncountable {
	

	public double getLitre(); // returns the litre of IUncountable item

	public void setLitre(double litre); // sets the litre of Icountable item
	
	
}
