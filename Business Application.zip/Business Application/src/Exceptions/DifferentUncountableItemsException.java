package Exceptions;

@SuppressWarnings("serial")
public class DifferentUncountableItemsException extends Exception { 
	   
	public DifferentUncountableItemsException(String errorMessage) {
	        super(errorMessage);
	    }
	}
