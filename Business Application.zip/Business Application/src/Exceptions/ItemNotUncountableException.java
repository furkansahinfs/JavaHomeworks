package Exceptions;

@SuppressWarnings("serial")
public class ItemNotUncountableException extends Exception{
	public ItemNotUncountableException(String e) {
        super(e);
       
    }

}
