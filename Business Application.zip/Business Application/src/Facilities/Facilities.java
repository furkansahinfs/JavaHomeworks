package Facilities;

import Collections.IContainer;

public class Facilities 
{
	
	public <T> boolean add(T eleman)  
	{
		return false;
	}
	public <T> boolean remove(T eleman) 
	{
		return false;
	}
	public <T> boolean transferTo(T eleman, Facilities faci,IContainer container)  throws Exception 
	{
		return false;
	}
}
